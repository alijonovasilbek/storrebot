from time import time

from aiogram import Router, F
from aiogram.enums import ParseMode
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart, Command

from config import DB_NAME, admins
from keyboards.client_inline_keyboards import get_category_list, get_product_list
from states.client_states import ClientAdsStates
from utils.database import Database
from utils.my_commands import commands_user
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, InputMediaPhoto

ads_router = Router()
db = Database(DB_NAME)

#
# @ads_router.message(F.photo)
# async def test(message: Message, album: list(Message)):
#     print(album)


@ads_router.message(Command('new_ad'))
async def new_ad_handler(message: Message, state: FSMContext):
    await state.set_state(ClientAdsStates.selectAdCategory)
    await message.answer(
        "Please, choose a category for your ad: ",
        reply_markup=get_category_list()
    )


@ads_router.callback_query(ClientAdsStates.selectAdCategory)
async def select_ad_category(callback: CallbackQuery, state: FSMContext):
    await state.set_state(ClientAdsStates.selectAdProduct)
    await callback.message.edit_text(
        "Please, choose a product type for your ad: ",
        reply_markup=get_product_list(int(callback.data))
    )


@ads_router.callback_query(ClientAdsStates.selectAdProduct)
async def select_ad_product(callback: CallbackQuery, state: FSMContext):
    await state.set_state(ClientAdsStates.insertTitle)
    await state.update_data(ad_product=callback.data)
    await callback.message.answer(
        f"Please, send title for your ad!\n\n"
        f"For example:"
        f"\n\t- iPhone 15 Pro Max 8/256 is on sale"
        f"\n\t- Macbook Pro 13\" M1 8/256 is on sale"
    )
    await callback.message.delete()


@ads_router.message(ClientAdsStates.insertTitle)
async def ad_title_handler(message: Message, state: FSMContext):
    await state.update_data(ad_title=message.text)
    await state.set_state(ClientAdsStates.insertText)
    await message.answer("OK, please, send text(full description) for your ad.")


@ads_router.message(ClientAdsStates.insertText)
async def ad_text_handler(message: Message, state: FSMContext):
    await state.update_data(ad_text=message.text)
    await state.set_state(ClientAdsStates.insertPrice)
    await message.answer("OK, please, send price for your ad (only digits).")


@ads_router.message(ClientAdsStates.insertPrice)
async def ad_price_handler(message: Message, state: FSMContext):
    if message.text.isdigit():
        await state.update_data(ad_price=int(message.text))
        await state.set_state(ClientAdsStates.insertImages)
        await message.answer("OK, please, send image(s) for your ad.")
    else:
        await message.answer("Please, send only number...")


@ads_router.message(ClientAdsStates.insertImages)
async def ad_photo_handler(message: Message, state: FSMContext):
    if message.photo:
        await state.update_data(ad_photo=message.photo[-1].file_id)
        await state.set_state(ClientAdsStates.insertPhone)
        await message.answer("OK, please, send phone number for contact with your.")
    else:
        await message.answer("Please, send image(s)...")


@ads_router.message(ClientAdsStates.insertPhone)
async def ad_phone_handler(message: Message, state: FSMContext):
    await state.update_data(ad_phone=message.text)
    all_data = await state.get_data()
    try:
        x = db.insert_ad(
            title=all_data.get('ad_title'),
            text=all_data.get('ad_text'),
            price=all_data.get('ad_price'),
            image=all_data.get('ad_photo'),
            phone=all_data.get('ad_phone'),
            u_id=message.from_user.id,
            prod_id=all_data.get('ad_product'),
            date=time()
        )
        if x:
            await state.clear()
            await message.answer("Your ad successfully added!")
        else:
            await message.answer("Something error, please, try again later...")
    except:
        await message.answer("Resend phone please...")


@ads_router.message(Command('ads'))
async def ads_list_handler(message: Message):
    cursor = db.get_my_ads(message.from_user.id)
    my_ads = cursor.fetchall()  
    if not my_ads:
        await message.answer("Sizda elonlar ,avjud emas.")
        return

    ad = my_ads[0]
    caption = f"<b>{ad[1]}</b>\n\n{ad[2]}\n\nNarxi: ${ad[3]}\n\nElon 1 dan {len(my_ads)}"
    await message.answer_photo(
        photo=ad[4],
        caption=caption,
        parse_mode=ParseMode.HTML,
        reply_markup=get_inline_ad_navigation_keyboard(0, len(my_ads))
    )


def get_inline_ad_navigation_keyboard(current_index, total_ads):
    buttons = []
    if current_index > 0:
        buttons.append(InlineKeyboardButton(text="⬅️", callback_data=f"prev_ad_{current_index - 1}"))
    if current_index < total_ads - 1:
        buttons.append(InlineKeyboardButton(text="➡️", callback_data=f"next_ad_{current_index + 1}"))
    return InlineKeyboardMarkup(inline_keyboard=[buttons])




@ads_router.callback_query()
async def inline_button_handler(callback: CallbackQuery):
    data = callback.data.split('_')
    if len(data) != 3 or data[0] not in ['prev', 'next'] or not data[2].isdigit():
        await callback.answer()
        return

    action = data[0]
    index = int(data[2])

    if action == "prev":
        if index > 0:
            my_ads = db.get_my_ads(callback.from_user.id).fetchall()
            previous_ad = my_ads[index - 1]
            await show_ad(callback, previous_ad, index - 1) 
    elif action == "next":
        my_ads = db.get_my_ads(callback.from_user.id).fetchall()
        if index < len(my_ads) - 1:
            next_ad = my_ads[index + 1]
            await show_ad(callback, next_ad, index + 1)  
        else:
            await callback.answer("Boshqa elon topilmadi.")



async def show_ad(callback: CallbackQuery, ad: tuple, index: int):
    
    caption = f"<b>{ad[1]}</b>\n\n{ad[2]}\n\nNarxi: ${ad[3]}\n\nElon {index + 1}"
    media = InputMediaPhoto(media=ad[4], caption=caption, parse_mode=ParseMode.HTML)
    
    await callback.message.edit_media(
        media=media,
        reply_markup=get_inline_ad_navigation_keyboard(index, callback.message.chat.id)
    )
    await callback.answer()


@ads_router.message(Command('del_ad'))
async def delete_ad_handler(message: Message, state: FSMContext):
    my_ads = db.get_my_ads(message.from_user.id).fetchall()
    if my_ads:
        ads_list = "\n".join([f"{index + 1}. {ad[1]}" for index, ad in enumerate(my_ads)])
        await state.update_data(my_ads=my_ads)
        await message.answer(f"Sizning elonlaringiz:\n{ads_list}\nEloning yonidagi raqamni kiriting (ehtiyot boling raqmni kiritganingizdan song eloningiz ochib ketadi):")
        await state.set_state(ClientAdsStates.selectDeleteAd)
    else:
        await message.answer("Sizda elon mavjud emas.")

@ads_router.message()
async def confirm_delete_ad(message: Message, state: FSMContext):
    if await state.get_state() == ClientAdsStates.selectDeleteAd:
        ad_number = int(message.text)
        my_ads = db.get_my_ads(message.from_user.id).fetchall()
        
        if 1 <= ad_number <= len(my_ads):
            ad_to_delete = my_ads[ad_number - 1]
            if db.delete_ad(ad_to_delete[0]): 
                await message.answer(f"Eloningiz {ad_number} ochirib yuborildi.")
            else:
                await message.answer("Hatolik yuz berdi.")
        else:
            await message.answer("elon raqami notogri kiritilgan.")

        await state.set_state(None) 



@ads_router.message(Command('edit_ad'))
async def edit_ad_handler(message: Message, state: FSMContext):
    my_ads = db.get_my_ads(message.from_user.id).fetchall()
    if my_ads:
        ads_list = "\n".join([f"{index + 1}. {ad[1]}" for index, ad in enumerate(my_ads)])
        await state.update_data(my_ads=my_ads)
        await message.answer(f"eloni tanglang:\n{ads_list}")
        await state.set_state(ClientAdsStates.selectEditAd)
    else:
        await message.answer("sizda elon yoq.")

@ads_router.message()
async def start_editing_ad(message: Message, state: FSMContext):
    if await state.get_state() == ClientAdsStates.selectEditAd:
        ad_number = int(message.text)
        my_ads = await state.get_data('my_ads')
        
        if 1 <= ad_number <= len(my_ads):
            ad_to_edit = my_ads[ad_number - 1]
            await state.update_data(ad_to_edit=ad_to_edit)
            await state.set_state(ClientAdsStates.insertTitle)
            await message.answer("Yegi nom kiriting:")
        else:
            await message.answer("notogri.")

@ads_router.message(ClientAdsStates.insertTitle)
async def edit_ad_title_handler(message: Message, state: FSMContext):
    await state.update_data(new_ad_title=message.text)
    await state.set_state(ClientAdsStates.insertText)
    await message.answer("Yengi matn kiriting")

@ads_router.message(ClientAdsStates.insertText)
async def edit_ad_text_handler(message: Message, state: FSMContext):
    await state.update_data(new_ad_text=message.text)
    await state.set_state(ClientAdsStates.insertPrice)
    await message.answer("narx kiriring (faqat son):")

@ads_router.message(ClientAdsStates.insertPrice)
async def edit_ad_price_handler(message: Message, state: FSMContext):
    if message.text.isdigit():
        await state.update_data(new_ad_price=int(message.text))
        await state.set_state(ClientAdsStates.insertImages)
        await message.answer("rasm yuboring.")
    else:
        await message.answer("faqat raqamdan foydalaning.")

@ads_router.message(ClientAdsStates.insertImages)
async def edit_ad_images_handler(message: Message, state: FSMContext):
    if message.photo:
        await state.update_data(new_ad_photo=message.photo[-1].file_id)
        await state.set_state(ClientAdsStates.insertPhone)
        await message.answer("telefon raqam kiriring.")
    else:
        await message.answer("rasm yuboring.")

@ads_router.message(ClientAdsStates.insertPhone)
async def edit_ad_phone_handler(message: Message, state: FSMContext):
    await state.update_data(new_ad_phone=message.text)
    await confirm_edit_ad_changes(message, state)

async def confirm_edit_ad_changes(message: Message, state: FSMContext):
    all_data = await state.get_data()
    ad_to_edit = all_data.get('ad_to_edit')

    try:
        db.update_ad(
            ad_id=ad_to_edit[0],
            title=all_data.get('new_ad_title'),
            text=all_data.get('new_ad_text'),
            price=all_data.get('new_ad_price'),
            image=all_data.get('new_ad_photo'),
            phone=all_data.get('new_ad_phone')
        )
        await state.clear()
        await message.answer("eloningiz yangilandi!")
    except:
        await message.answer("hatolik yuz berdi keynroq urinib koring.")
